To set up the databse
open file 'config.php'
set the following variables

$servername
$username
$password
$dbname

databse file is '334.sql'